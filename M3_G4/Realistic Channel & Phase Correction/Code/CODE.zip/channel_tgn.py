"""
TGn Model C channel utilities for M3.

The tap delays and cluster powers are taken from IEEE 802.11-03/940
Appendix C, Model C. Model C has 14 tap delays from 0 to 200 ns.
Where the two clusters overlap at a delay, their powers are added in
linear power before drawing the complex Gaussian tap coefficient.

The simulator later normalizes the resulting frequency response so that
mean(|b_k|^2)=gamma and removes the linear phase slope so that
sum_k angle(b_k b*_{k+1}) = 0.
"""
import numpy as np

# IEEE 802.11-03/940 Model C
TGn_C_DELAYS_NS = np.array(
    [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 110, 140, 170, 200],
    dtype=float,
)

# Cluster 1 occupies taps 1--10.
TGn_C_CLUSTER1_DB = np.array(
    [0, -2.1, -4.3, -6.5, -8.6, -10.8, -13.0, -15.2, -17.3, -19.5],
    dtype=float,
)

# Cluster 2 occupies taps 7--14.
TGn_C_CLUSTER2_DB = np.array(
    [-5.0, -7.2, -9.3, -11.5, -13.7, -15.8, -18.0, -20.2],
    dtype=float,
)


def tgn_model_c_pdp():
    """Return Model-C delays and combined average tap powers in dB."""
    p1 = np.zeros(14)
    p2 = np.zeros(14)
    p1[:] = 0.0
    p2[:] = 0.0
    p1[:10] = 10.0 ** (TGn_C_CLUSTER1_DB / 10.0)
    p2[6:] = 10.0 ** (TGn_C_CLUSTER2_DB / 10.0)
    p = p1 + p2
    return TGn_C_DELAYS_NS * 1e-9, 10.0 * np.log10(p), p / p.sum()


def tgn_model_c_taps(rng):
    """
    Draw one independent quasi-static Rayleigh realization of the
    standardized Model-C tapped-delay line.

    The expected power of each complex tap is proportional to the
    standardized combined PDP.
    """
    delays, pdb, pnorm = tgn_model_c_pdp()
    taps = (
        rng.standard_normal(len(delays))
        + 1j * rng.standard_normal(len(delays))
    ) / np.sqrt(2.0)
    taps *= np.sqrt(pnorm)
    return delays, taps, pdb, pnorm


def frequency_response(K, Ts, rng):
    """Generate a Model-C frequency response on f_k=k/Ts."""
    delays, taps, pdb, pnorm = tgn_model_c_taps(rng)
    f = np.arange(K, dtype=float) / Ts
    b = np.exp(-2j * np.pi * f[:, None] * delays[None, :]) @ taps
    return b, f, delays, pdb, pnorm
