"""
M3 master runner.

This script intentionally launches each curve in a fresh Python process.
That keeps the 500-trial experiments isolated and makes the run reproducible.
It also splits the largest K curves into smaller chunks only for execution;
the final statistics are recomputed from all 500 raw trial values.

Usage:
    python run_m3.py
"""
import json, subprocess, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from channel_tgn import tgn_model_c_pdp

ROOT=Path(__file__).resolve().parent
HELPER=ROOT/"run_single_curve.py"
N=500

def run(kind,value,n=500,offset=0):
    subprocess.run([sys.executable,str(HELPER),kind,str(value),str(n),str(offset)],cwd=ROOT,check=True)

def raw(kind,value):
    vals={}
    for f in sorted(ROOT.glob(f"curve_{kind}_{value:g}_*.json")):
        d=json.load(open(f))
        for m,r in d.items():
            vals.setdefault(m,[]).extend(r["snr_values"])
    return vals

def summarize(x,seed):
    x=np.asarray(x,float); n=len(x)
    rng=np.random.default_rng(seed)
    idx=rng.integers(0,n,size=(1000,n))
    bm=np.median(x[idx],axis=1)
    lo,hi=np.percentile(bm,[2.5,97.5]); q1,q3=np.percentile(x,[25,75])
    return {"median_db":float(10*np.log10(max(np.median(x),1e-15))),
            "q1_db":float(10*np.log10(max(q1,1e-15))),
            "q3_db":float(10*np.log10(max(q3,1e-15))),
            "ci95_median_db":[float(10*np.log10(max(lo,1e-15))),float(10*np.log10(max(hi,1e-15)))],
            "n_trials":n}

def collect(kind,values):
    out={}
    for v in values:
        out[v]={m: summarize(x,50000+int(round(v*1e9))+i)
                for i,(m,x) in enumerate(raw(kind,v).items())}
    return out

def plot(data,fname,xlabel,title):
    fig,ax=plt.subplots(figsize=(7.2,4.8))
    for m,rows in data.items():
        xs=[r["x"] for r in rows]; ys=[r["median_db"] for r in rows]
        lo=[r["ci95_median_db"][0] for r in rows]; hi=[r["ci95_median_db"][1] for r in rows]
        ax.plot(xs,ys,marker="o",label=m); ax.fill_between(xs,lo,hi,alpha=.16)
    ax.set_xlabel(xlabel); ax.set_ylabel("Median SNR metric [dB]")
    ax.set_title(title); ax.grid(alpha=.25); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(ROOT/fname,dpi=180); plt.close(fig)

def main():
    # E1
    for g in [.5,.7,.8,.9,.95,.99]:
        run("e1",g)
    e1=collect("e1",[.5,.7,.8,.9,.95,.99])
    e1plot={m:[dict(r,x=x) for x,r in []] for m in []}
    for m in e1:
        e1plot[m]=[]
        for x in [.5,.7,.8,.9,.95,.99]:
            e1plot[m].append(dict(e1[x][m],x=float(x)))
    plot(e1plot,"M3_E1_phase_vs_gamma.png","Static-channel power fraction γ","M3 E1: TGn Model-C phase correction (500 trials)")

    # E3
    tm=[1e-7,4e-7,8e-7,1.6e-6,2.4e-6,3.2e-6]
    for t in tm: run("e3",t)
    e3=collect("e3",tm)
    e3plot={}
    for m in e3[tm[0]]:
        e3plot[m]=[dict(e3[t][m],x=float(t*1e9)) for t in tm]
    plot(e3plot,"M3_E3_phase_vs_timing.png","Maximum timing error τmax [ns]","M3 E3: timing-error stress test (500 trials)")

    # E4. K=256 and K=512 are split into independent processes.
    run("e4",64); run("e4",128)
    for off in [0,250]: run("e4",256,250,off)
    for off in [0,125,250,375]: run("e4",512,125,off)
    e4=collect("e4",[64,128,256,512])
    e4plot={}
    for m in e4[64]:
        e4plot[m]=[dict(e4[k][m],x=float(k)) for k in [64,128,256,512]]
    plot(e4plot,"M3_E4_phase_vs_K.png","Number of subcarriers K","M3 E4: bandwidth scaling (500 trials)")

    # Channel validation
    delays,pdb,pnorm=tgn_model_c_pdp()
    fig,ax=plt.subplots(figsize=(7.2,4.8))
    ax.stem(delays*1e9,10*np.log10(pnorm),linefmt="C0-",markerfmt="C0o",basefmt=" ")
    ax.set(xlabel="Excess delay [ns]",ylabel="Normalized tap power [dB]",title="M3: IEEE 802.11 TGn Model-C PDP")
    ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(ROOT/"M3_channel_PDP.png",dpi=180); plt.close(fig)

    # K=256 paper-style result is the same 500 trials as E4.
    report={"trials_per_curve":500,"P":300,"Ts_s":3.2e-6,"subcarrier_spacing_Hz":312500.0,
            "E1":e1plot,"E3":e3plot,"E4":e4plot,
            "K256_paper_style":e4[256]}
    json.dump(report,open(ROOT/"M3_results.json","w"),indent=2)

if __name__=="__main__":
    main()
