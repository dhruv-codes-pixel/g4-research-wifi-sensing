# Real-data analysis (Member D — Dhruv)

## 1. Status (read this first)
**No real-CSI results exist yet.** The Portner et al. (Sensession) dataset was not accessible to the team (evidence: `Results/real_data/log.txt`, `data_check.md`). The OpenCSI fallback dataset was identified but not obtained, and its raw-file format is undocumented, so no loader was written for it. Nothing in this repository is simulated data presented as real. Every results file that depends on real data is either marked `NOT_RUN` or absent, and is produced by one command (section 6).

## 2. Objective
Apply the M2 correction methods to real CSI from different receivers and quantify how much residual error remains: raw CSI, Eq. 6, Eq. 21, Eq. 22, Algorithm 4 + Eq. 25, Algorithm 1, the M2 Algorithm 3 (known to pick λ≈3.5 dB instead of 0.5 dB) and the fixed Algorithm 3 if Member B delivers `gain_fix.py`.

## 3. Method (implemented in `Code/real_data.py`)
- Load complex CSI as packets × subcarriers; drop NaN packets, the first 200 packets (AGC warm-up), guard subcarriers (|idx|>28), DC, and interpolated iwl5300 subcarriers.
- One trial = one random contiguous window of 500 packets (seeded). Each window is scaled by a single global constant (per-packet gain is untouched).
- Gain methods are scored by amplitude residual; phase methods are applied after Eq. 6 gain correction and scored by phase residual. Sub-bands: 16, 32, all (subcarriers nearest the band centre).
- **Amplitude residual:** r[p,k] = 20·log10|h[p,k]| − mean over p. Reported: RMS over (p,k) in dB, and the std over p of the per-packet mean over k (common-mode part, which gain correction targets).
- **Phase residual:** reference = time-averaged channel per subcarrier; r = angle(h · conj(ref)). Reported: RMS over (p,k) in degrees, and RMS of the per-packet common phase.
- Interpretation rule: on a static cable channel the true channel is constant, so remaining variation is error. This only holds for static, cabled recordings.

## 4. Results
Not available — see section 1. When the script is run, `Results/real_data/residual_comparison.csv`, `subband_comparison.png` and `real_data_results.npz` are generated and this section must be filled with the actual numbers, reported as they come out (including cases where a correction makes things worse).

## 5. Limitations (known before any data)
- No real data processed yet; nothing here validates the methods on hardware.
- Portner data (if obtained): static over-the-cable, 20 MHz, single antenna, ≤56 subcarriers (30 on iwl5300 → no 32-subcarrier sub-band there; Eq. 22/Algorithm 4 not applicable at spacing 2). No multipath, so this tests hardware error only. No ground truth gain/phase exists for the base campaign, so a lower residual means less packet-to-packet variation, not proven correctness.
- OpenCSI (if used instead): a room with people, not a cable; only the 5-minute quiet baseline is a candidate static interval, and real channel drift is then mixed with hardware error; 52 subcarriers on S3/C3; 246 on C6 (not supported by the 64-point setup). It would be real multi-device validation, not over-the-cable replication.
- DC removal puts one double-spacing pair into the Eq. 22 / Algorithm 4 coarse step (1 of ~55 pairs; small bias).
- `csi_sim.py` fixes Ts = 3.2 µs and a 0.1 s packet interval for the Algorithm 1/3 low-pass filter; the script sets the interval to the measured value at runtime. Algorithm 1/3 results depend on this.
- The M2 Algorithm 3 is known broken; it is reported as `Algo3_M2`, not as the paper's method.

## 6. How to produce the results
    pip install numpy scipy scikit-learn matplotlib polars pyarrow
    python Code/real_data.py --data-dir <folder with csi.parquet + meta.parquet> --out Results/real_data --trials 20 --window 500 --seed 1
