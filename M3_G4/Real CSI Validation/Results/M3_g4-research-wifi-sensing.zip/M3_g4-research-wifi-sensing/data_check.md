# data_check.md — Member D (Dhruv): Portner et al. dataset check

Date of check: 2026-11-01. Status as of 2026-11-01 evening: **Portner/4TU dataset located and documented but NOT downloaded (inaccessible to the team); no real-data results exist in this repo.** A fallback dataset (OpenCSI) was identified but not yet obtained/inspected (section 6).

## 1. What I could and could not access (evidence)
| Source | Result |
|---|---|
| `https://doi.org/10.4121/48e1331b-91df-4e1a-906b-b0a0e9d16c74` from the analysis sandbox | `curl: (56) CONNECT tunnel failed, response 403` (blocked by sandbox network allowlist). Dhruv also reports the DOI link does not open in his browser. |
| `https://data.4tu.nl/datasets/48e1331b-91df-4e1a-906b-b0a0e9d16c74` (found by web search) | Readable through the sandbox's page fetcher. File list below comes from here. |
| `https://research.tudelft.nl/en/datasets/data-and-code-for-same-signal-different-story-demystifying-receiv/` | Readable. Confirms receivers, format, cable setup. |
| arXiv 2605.26836 (paper) | Readable. Confirms measurement setup and data-availability statement. |
| GitHub repo `nzqo/sensession` | Provided as a zip by Dhruv (code only: **no data files inside**). |
| Raw data download (any `.zip`) | **Not possible from the sandbox. Must be downloaded by Dhruv from 4TU.** |

Note: summaries of the web pages above were produced by a page-fetch tool, not by me reading the raw pages. Items marked (verify) must be confirmed on the page/PDF before going into the report.

## 2. Dataset facts
- Title: *Data and Code for "Same Signal, Different Story: Demystifying Receiver Effects in Wi-Fi CSI"*, Portner, Asadi, Gringoli, Hollick. DOI 10.4121/48e1331b-91df-4e1a-906b-b0a0e9d16c74. (TU Delft portal shows publication 20 Oct 2025 while the arXiv ID is 2605.* — publication status/version to be verified by Member A.)
- Format: `.parquet` (CSI: `csi.parquet` + `meta.parquet`), plus `.py/.md/.pdf/.ipynb/.zip`. CSI stored as nested lists `[antenna][stream][subcarrier]`, as `csi_abs` and `csi_phase`. (Repo: `src/sensession/database.py`, `scripts/parquet_to_numpy.py`.)
- Total: 23 zip files, ~156.9 GB (156,947,103,147 bytes) — **do not download everything.**
- Setup: transmitter USRP N2954-R, frames generated with MATLAB WLAN Toolbox (802.11n, 20 MHz, single antenna). For the controlled/"over-the-wire" data all receivers are connected by **cables of equal length through a power splitter** (ZN8PD1-63W-S+). HAR data uses antennas instead (human moves) — not usable as static data.

### Device table (8 receivers, 6 models)
| receiver_name | Device | Notes |
|---|---|---|
| x310 | USRP N2954-R | no AGC; tracks ground-truth gain (paper) |
| qca | Qualcomm Atheros QCA AR9462 | gain changes look random (paper) |
| ax210 | Intel AX210 | small, frequent gain steps (paper) |
| iwl5300 | Intel IWL5300 | only 30 reported subcarriers (paper); PicoScenes interpolates the rest (repo) |
| asus1, asus2 | Asus RT-AC86U (Nexmon) | large, infrequent gain steps (paper) |
| ESP1, ESP2 | ESP32-S3 | gain changes hard to tell from noise (paper) |
Subcarriers: 64-FFT, 312.5 kHz spacing. Repo keeps indices -28..28 without DC = 56 (iwl5300: 30).

### Files (bytes) — relevant ones
| File | Size | Use for M3 |
|---|---|---|
| `base_campaign_ch11.zip` | 564,680,823 (~539 MiB) | **Recommended.** Paper: 10,000 repetitions of an *unmodified* packet over cable (verify in paper). Repo `evaluation/base` reads it. |
| `random_curves_18dbgain.zip` | 111,534,925 | Optional: contains `curves.parquet` (applied gain curves = ground truth for gain correction). Content not verified. |
| `ax210_averaging.zip` | 27,743,564 | AX210 only; not multi-receiver. |
| `methodology.zip` | 7,093,536 | Smallest, but frames carry a deliberate single-subcarrier mask (`experiments/_20_methodology.py`) → **not a clean static recording.** |
| `doppler_emulation_slow.zip` | 266,539,412 | Emulated motion — not static. |
| `single_*_ch*.zip`, `wise-har-dataset.zip` | 5.8–11.3 GB each | Too large / not static. Skip. |

## 3. Decision
Download **only `base_campaign_ch11.zip`** (~539 MiB). Unzip to `Data/base_campaign_ch11/` so that `csi.parquet` and `meta.parquet` sit together (zip may contain a sub-folder; `run_real_data.py --data-dir` must point at the folder holding both).

## 4. Still to verify once the file is on disk (do not assume)
1. receivers present in `meta.parquet` and packets per receiver (`rd.inventory`), incl. whether all 8 are in this campaign;
2. packet rate / `timestamp` dtype (loader only measures interval if `timestamp` is a Datetime);
3. that the recordings are indeed unmodified/static (no mask) and over cable, per paper Sec. on base campaign;
4. subcarrier index layout (`subcarrier_idxs` in meta);
5. whether iwl5300 data is 30 or 56 (interpolated) subcarriers.

## 5. Known limitations (already identified from code, before any data)
- Static cable channel: no multipath, tiny delay spread → tests residual hardware error only, not realistic channel conditions. Not over-the-air.
- Only 20 MHz, single antenna/stream; at most 56 subcarriers (30 on iwl5300), so "all" = 56, and a 32-subcarrier sub-band is skipped for iwl5300.
- DC removed → one double-spacing pair in Eq.(22)/Algo 4 coarse step (1 of 55 pairs), small bias. Eq.(22)/Algo 4 are **not applicable** to iwl5300 (spacing 2 ≠ 1/Ts).
- `csi_sim.py` hard-codes Ts = 3.2 µs and packet interval TREP = 0.1 s for Algo 1/3 low-pass; runner sets `TREP` to the measured interval at runtime (file unchanged). Algo 1/3 outcomes depend on that.
- Algorithm 3 (M2 version) is known-broken (λ≈3.5 dB). Reported as `Algo3_M2`. If Member B delivers `gain_fix.py` with `gain_algo3_fixed(ht)`, it is picked up automatically as `Algo3_fixed`.
- Amplitude normalisation: one global constant per window; Algo 4's `thr=0.1` assumes mean|b|²≈1, which this normalisation provides.
- Residual metrics use the time-averaged channel as reference; they measure packet-to-packet error, not absolute accuracy. No ground-truth gain/phase exists for the base campaign.
- A pipeline smoke test was run on **synthetic** data in the real file format only to check the code executes. Those numbers are not results and are not in `Results/`.


## 6. Fallback dataset considered: OpenCSI LCN 2026 (Zenodo record 19861032) — NOT yet obtained
Information below comes only from the dataset's own README.md and DATASHEET.md (read by the author); the data itself has not been opened.
- Raw CSI from ESP32 nodes: envA_S3, envB_S3prime, envC_C3 (802.11n HT20, 52 subcarriers) and envA_C6 (802.11ax HE20, 246 subcarriers). 8 nodes, 56 directed links, 20 Hz, 12 min per trial, CC BY 4.0, archive ~723.8 MB.
- Protocol per trial: 5 min quiet baseline, 3 min static occupancy, 2 min movement, 2 min empty room. Only the quiet baseline is a candidate "static" interval.
- Differences from the original task: not over-the-cable, no common transmitter/power splitter reference, each link has its own real channel, no ground-truth gain/phase. It would be a real multi-device CSI validation, **not** an over-the-cable replication.
- Must use `raw/csi_raw.jsonl.zst` only; `calibrated/` and `opencsi/` contain the OpenCSI authors' own processed outputs, not raw CSI.
- The README does not document the fields inside `csi_raw.jsonl.zst` (complex vs I/Q ints, subcarrier indexing, timestamps, link ids). A loader for it has **not** been written because the format is unverified.
- Network access from the analysis sandbox to zenodo.org also failed (see Results/real_data/log.txt).
