# M3 — Member D (Dhruv): real CSI validation

| Path | State |
|---|---|
| `Code/real_data.py` | done and tested only on a synthetic file in the real format (pipeline check, not a result) |
| `Code/csi_sim.py` | unchanged copy of the M2 file (delete if the repo already has it; `real_data.py` finds it in `Code/` or `Code/src/`) |
| `data_check.md` | done: dataset facts, access evidence, fallback dataset, limitations |
| `Results/real_data/dataset_info.csv` | done: device/file table from the dataset pages (sources stated) |
| `Results/real_data/log.txt` | done: access-attempt log; real runs append to it |
| `Results/real_data/experiment_config.json` | placeholder (`status: not_run`); overwritten by a real run |
| `Results/real_data/residual_comparison.csv` | placeholder (`NOT_RUN`); overwritten by a real run |
| `Results/real_data/subband_comparison.png`, `real_data_results.npz`, `dataset_recordings.csv` | **do not exist yet** - created by a real run |
| `Report/real_data_analysis.md` | done except Results section (needs real run) |

## Still to do (cannot be done without real data / your repo access)
1. Obtain a real recording: `base_campaign_ch11.zip` from 4TU (MD5 `8d86c2a69d4f37b03b3c0a56626a9390`, 564,680,823 bytes) or the OpenCSI raw files.
2. Run `python Code/real_data.py --data-dir <dir> --out Results/real_data --trials 20 --window 500 --seed 1`; fill section 4 of `Report/real_data_analysis.md` and the "still to verify" items in `data_check.md`.
3. Git: create branch `m3-real-data`, make at least 5 genuine commits across both days, open a PR, get it merged; send `.npz`/`.json`/log/figures to Lay (statistics) and the written section to Pratyusha; submit your Google Form.
4. If OpenCSI is used, a loader is needed: send the first lines of `raw/csi_raw.jsonl.zst` and `trial.json` so it can be written against the real format.
