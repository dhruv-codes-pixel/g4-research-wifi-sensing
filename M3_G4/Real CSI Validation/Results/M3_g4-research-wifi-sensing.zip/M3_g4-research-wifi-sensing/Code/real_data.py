"""
real_data.py -- Member D (Dhruv): apply the M2 CSI correction methods to REAL CSI.

Loads complex CSI (packets x subcarriers) from real recordings, applies
  raw CSI | Eq.6 | Eq.21 | Eq.22 | Algorithm 4 + Eq.25 | Algorithm 1 | Algorithm 3 (M2, known-broken) | fixed Algorithm 3 (gain_fix.py, if present)
on 16 / 32 / all subcarriers, computes amplitude + phase residuals, and writes every deliverable in Results/real_data/.

Supported input format: Sensession / Portner et al. recordings (csi.parquet + meta.parquet, or NPY backend).
This script NEVER generates or simulates CSI. If the data folder is missing it stops with an error.

  python Code/real_data.py --data-dir Data/base_campaign_ch11 --out Results/real_data --trials 20 --window 500 --seed 1

csi_sim.py is imported unchanged (looked up in Code/ or Code/src/).
"""
import argparse, csv, json, subprocess, sys, time
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
for p in (HERE, HERE / "src"):
    sys.path.insert(0, str(p))
import csi_sim as cs                                         # unchanged M2 module

TS = 3.2e-6                                                  # 20 MHz, 64-pt FFT -> 312.5 kHz spacing (same as csi_sim.TS)
VALID_IWL = list(range(-28, -1, 2)) + list(range(-1, 28, 2)) + [28]   # real (non-interpolated) iwl5300 subcarriers, from sensession
GAIN_METHODS = ["raw", "Eq6", "Algo1", "Algo3_M2", "Algo3_fixed"]
PHASE_METHODS = ["raw", "Eq6+none", "Eq6+Eq21", "Eq6+Eq22", "Eq6+Algo4Eq25"]


# ============================================================ loading
def inventory(rec_dir):
    import polars as pl
    rec_dir = Path(rec_dir)
    meta = pl.read_parquet(rec_dir / "meta.parquet")
    if (rec_dir / "csi.parquet").is_file():
        cnt = pl.scan_parquet(rec_dir / "csi.parquet").group_by("meta_id").len().rename({"len": "n_packets"}).collect()
        meta = meta.join(cnt, on="meta_id", how="left")
    keep = [c for c in ("meta_id", "receiver_name", "channel", "bandwidth", "collection_start", "schedule_name", "n_packets") if c in meta.columns]
    return meta.select(keep)


def load_csi(rec_dir, receiver, meta_id=None, antenna=0, stream=0, warmup=200):
    """-> dict(csi PxK complex, sc_idx, f [Hz], t [s]|None, info). Drops NaN packets, first `warmup` packets (AGC warm-up),
    guard subcarriers (|idx|>28), DC and (iwl5300) interpolated subcarriers."""
    import polars as pl
    rec_dir = Path(rec_dir)
    meta = pl.read_parquet(rec_dir / "meta.parquet").filter(pl.col("receiver_name") == receiver)
    if meta.height == 0:
        raise ValueError(f"receiver {receiver!r} not found in meta.parquet")
    meta = meta.head(1) if meta_id is None else meta.filter(pl.col("meta_id") == meta_id)
    row = meta.row(0, named=True); mid = row["meta_id"]
    sc_idx = np.asarray(row["subcarrier_idxs"], dtype=int)
    t = None
    if row.get("relative_csi_path"):
        z = np.load(rec_dir / row["relative_csi_path"]); csi = z["csi"][:, antenna, stream, :]
    else:
        df = pl.scan_parquet(rec_dir / "csi.parquet").filter(pl.col("meta_id") == mid).select(["csi_abs", "csi_phase", "timestamp"]).collect()
        a = np.array(df["csi_abs"].to_list(), float)[:, antenna, stream, :]
        p = np.array(df["csi_phase"].to_list(), float)[:, antenna, stream, :]
        csi = a * np.exp(1j * p)
        ts = df["timestamp"]
        if ts.dtype == pl.Datetime:
            t = ts.cast(pl.Int64).to_numpy().astype(float) * {"ns": 1e-9, "us": 1e-6, "ms": 1e-3}[ts.dtype.time_unit]; t -= t[0]
    n_raw = csi.shape[0]
    ok = np.isfinite(csi).all(1); csi = csi[ok]; t = t[ok] if t is not None else None
    csi = csi[warmup:]; t = t[warmup:] if t is not None else None
    if csi.shape[1] != len(sc_idx):
        raise ValueError(f"CSI has {csi.shape[1]} subcarriers, meta lists {len(sc_idx)}")
    keep = (np.abs(sc_idx) <= 28) & (sc_idx != 0)
    if receiver == "iwl5300": keep &= np.isin(sc_idx, VALID_IWL)
    csi, sc_idx = csi[:, keep], sc_idx[keep]
    o = np.argsort(sc_idx); csi, sc_idx = csi[:, o], sc_idx[o]
    dt = float(np.median(np.diff(t))) if t is not None and len(t) > 2 else None
    info = dict(receiver=receiver, meta_id=str(mid), n_packets_raw=n_raw, n_nan_dropped=int((~ok).sum()), warmup_dropped=warmup,
                n_packets=int(csi.shape[0]), n_subcarriers=int(csi.shape[1]), sc_min=int(sc_idx.min()), sc_max=int(sc_idx.max()), median_dt_s=dt)
    return dict(csi=csi, sc_idx=sc_idx, f=sc_idx / TS, t=t, info=info)


def select_subband(csi, sc_idx, n):
    """n subcarriers nearest the band centre; n=None -> all; (None, None) if fewer than n are available."""
    if n is None or n == csi.shape[1]: return csi, sc_idx
    if n > csi.shape[1]: return None, None
    o = np.sort(np.argsort(np.abs(sc_idx), kind="stable")[:n]); return csi[:, o], sc_idx[o]


# ============================================================ residuals
def amp_residual(h):
    """r[p,k] = 20log10|h[p,k]| - mean_p(...). Returns (RMS over p,k [dB], std over p of mean_k r [dB] = common-mode)."""
    L = 20 * np.log10(np.abs(h) + 1e-300); r = L - L.mean(0, keepdims=True)
    return float(np.sqrt(np.mean(r ** 2))), float(np.std(r.mean(1)))


def phase_residual(h):
    """ref_k = mean_p h[p,k]; r = angle(h*conj(ref)). Returns (RMS over p,k [deg], RMS of per-packet common phase [deg])."""
    r = np.angle(h * np.conj(h.mean(0, keepdims=True)))
    cm = np.angle(np.exp(1j * r).sum(1)); cm = np.angle(np.exp(1j * (cm - np.angle(np.exp(1j * cm).mean()))))
    return float(np.degrees(np.sqrt(np.mean(r ** 2)))), float(np.degrees(np.sqrt(np.mean(cm ** 2))))


# ============================================================ methods
def gain_corrections(ht, log):
    out = {"raw": np.ones(ht.shape[0]), "Eq6": cs.gain_eq6(ht)}
    for name, fn in (("Algo1", cs.gain_algo1), ("Algo3_M2", cs.gain_algo3)):
        try: out[name] = fn(ht)
        except Exception as e: log(f"    {name} FAILED: {e!r}"); out[name] = None
    try:
        import gain_fix; out["Algo3_fixed"] = gain_fix.gain_algo3_fixed(ht)      # Member B's fix, if delivered
    except ImportError: pass
    except Exception as e: log(f"    Algo3_fixed FAILED: {e!r}"); out["Algo3_fixed"] = None
    return out


def phase_corrections(hb, f, sc_idx, log):
    out = {"Eq6+none": hb}
    try: t, s = cs.phase_eq21(hb, f); out["Eq6+Eq21"] = cs.apply_phase(hb, f, t, s)
    except Exception as e: log(f"    Eq21 FAILED: {e!r}"); out["Eq6+Eq21"] = None
    if np.median(np.diff(sc_idx)) != 1:           # Eq.22 / Algo4 coarse step assume neighbouring subcarriers are 1/Ts apart
        log("    Eq22 + Algo4 not applicable: subcarrier spacing != 1"); out["Eq6+Eq22"] = out["Eq6+Algo4Eq25"] = None; return out
    try: t, s = cs.phase_eq22(hb); out["Eq6+Eq22"] = cs.apply_phase(hb, f, t, s)
    except Exception as e: log(f"    Eq22 FAILED: {e!r}"); out["Eq6+Eq22"] = None
    try: t, s = cs.phase_algo4_eq25(hb, f); out["Eq6+Algo4Eq25"] = cs.apply_phase(hb, f, t, s)
    except Exception as e: log(f"    Algo4+Eq25 FAILED: {e!r}"); out["Eq6+Algo4Eq25"] = None
    return out


# ============================================================ outputs (all derived from saved trial arrays)
def write_outputs(out, res):
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    np.savez(out / "real_data_results.npz", **{k: np.array(v) for k, v in res.items()})
    rows = []
    for k, v in res.items():
        rcv, sb, kind, method, metric = k.split("|"); v = np.asarray(v, float); v = v[np.isfinite(v)]
        rows.append([rcv, sb, kind, method, metric, len(v)] + ([np.median(v), np.percentile(v, 25), np.percentile(v, 75)] if len(v) else [np.nan] * 3))
    with open(out / "residual_comparison.csv", "w", newline="") as f:
        w = csv.writer(f); w.writerow(["receiver", "subband", "kind", "method", "metric", "n_valid_trials", "median", "p25", "p75"]); w.writerows(rows)
    rcvs = sorted({r[0] for r in rows})
    fig, axs = plt.subplots(2, len(rcvs), figsize=(3.4 * len(rcvs), 6.4), squeeze=False)
    for j, rcv in enumerate(rcvs):
        for i, (kind, metric, unit) in enumerate((("amp", "rms_db", "dB"), ("phase", "rms_deg", "deg"))):
            ax = axs[i][j]
            for m in sorted({r[3] for r in rows if r[2] == kind}):
                pts = [(r[1], r[6], r[7], r[8]) for r in rows if r[0] == rcv and r[2] == kind and r[3] == m and r[4] == metric and np.isfinite(r[6])]
                if not pts: continue
                pts.sort(key=lambda p: (p[0] == "all", int(p[0]) if p[0] != "all" else 0)); x = np.arange(len(pts))
                ax.errorbar(x, [p[1] for p in pts], yerr=[[p[1] - p[2] for p in pts], [p[3] - p[1] for p in pts]], marker="o", capsize=2, label=m)
                ax.set_xticks(x); ax.set_xticklabels([p[0] for p in pts])
            ax.set_title(rcv); ax.set_xlabel("# subcarriers"); ax.set_ylabel(f"{kind} residual RMS [{unit}]"); ax.grid(alpha=.3)
    axs[0][0].legend(fontsize=6); axs[1][0].legend(fontsize=6)
    fig.suptitle("Real CSI: residual vs sub-band (median, IQR over trials)"); fig.tight_layout(); fig.savefig(out / "subband_comparison.png", dpi=150); plt.close(fig)


def git_hash():
    try: return subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, cwd=HERE).decode().strip()
    except Exception: return "not-a-git-repo"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", required=True, help="folder holding csi.parquet + meta.parquet (REAL data)")
    ap.add_argument("--out", default=str(HERE.parent / "Results" / "real_data"))
    ap.add_argument("--receivers", nargs="+", default=["all"])
    ap.add_argument("--subbands", nargs="+", default=["16", "32", "all"])
    ap.add_argument("--trials", type=int, default=20); ap.add_argument("--window", type=int, default=500)
    ap.add_argument("--seed", type=int, default=1); ap.add_argument("--warmup", type=int, default=200)
    ap.add_argument("--trep", type=float, default=None, help="packet interval [s] for Algo1/3 low-pass; default measured, else csi_sim default")
    a = ap.parse_args()
    if not (Path(a.data_dir) / "meta.parquet").is_file():
        sys.exit(f"ERROR: no meta.parquet in {a.data_dir}. Real data is required; this script does not simulate any.")
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    logf = open(out / "log.txt", "a")                       # append: keeps the access-attempt log already in the file
    def log(s): print(s); logf.write(s + "\n"); logf.flush()
    log(f"\n==== run_real_data {time.strftime('%Y-%m-%d %H:%M:%S')} seed={a.seed} trials={a.trials} window={a.window} data={a.data_dir}")
    inv = inventory(a.data_dir); log("inventory:\n" + str(inv))
    recs = sorted(set(inv["receiver_name"].to_list())) if a.receivers == ["all"] else a.receivers
    subbands = [None if s == "all" else int(s) for s in a.subbands]
    rng = np.random.default_rng(a.seed); res, infos = {}, {}
    for rcv in recs:
        try: d = load_csi(a.data_dir, rcv, warmup=a.warmup)
        except Exception as e: log(f"[{rcv}] LOAD FAILED: {e!r}"); infos[rcv] = dict(error=repr(e)); continue
        infos[rcv] = d["info"]; log(f"[{rcv}] {d['info']}")
        dt = a.trep or d["info"]["median_dt_s"]
        if dt: cs.TREP = dt                                   # runtime setting only; csi_sim.py file untouched
        log(f"[{rcv}] TREP for Algo1/3 = {cs.TREP} s")
        P = d["csi"].shape[0]; W = min(a.window, P)
        if W < a.window: log(f"[{rcv}] only {P} packets after warm-up; window = {W}")
        starts = rng.integers(0, P - W + 1, size=a.trials)
        for sb in subbands:
            nm = "all" if sb is None else str(sb); csi_sb, sc_sb = select_subband(d["csi"], d["sc_idx"], sb)
            if csi_sb is None: log(f"[{rcv}] sub-band {nm}: skipped, only {d['csi'].shape[1]} subcarriers"); continue
            f = sc_sb / TS
            for tr, s0 in enumerate(starts):
                lg = log if tr == 0 else (lambda s: None)
                ht = csi_sb[s0:s0 + W]; ht = ht / np.sqrt(np.mean(np.abs(ht) ** 2))      # one global constant per window
                put = lambda kind, m, name, v: res.setdefault(f"{rcv}|{nm}|{kind}|{m}|{name}", []).append(v)
                G = gain_corrections(ht, lg)
                for m, g in G.items():
                    r1, r2 = (np.nan, np.nan) if g is None else amp_residual(ht / g[:, None]); put("amp", m, "rms_db", r1); put("amp", m, "cm_db", r2)
                Pc = phase_corrections(ht / G["Eq6"][:, None], f, sc_sb, lg); Pc["raw"] = ht
                for m, h in Pc.items():
                    r1, r2 = (np.nan, np.nan) if h is None else phase_residual(h); put("phase", m, "rms_deg", r1); put("phase", m, "cm_deg", r2)
            log(f"[{rcv}] sub-band {nm} ({csi_sb.shape[1]} sc): {a.trials} trials done")
    inv.write_csv(out / "dataset_recordings.csv")
    json.dump(dict(status="run", args=vars(a), commit=git_hash(), per_receiver=infos, methods_gain=GAIN_METHODS, methods_phase=PHASE_METHODS,
                   metrics=dict(amp="rms_db, cm_db", phase="rms_deg, cm_deg"), data="REAL CSI only"), open(out / "experiment_config.json", "w"), indent=2)
    write_outputs(out, res); log(f"wrote results to {out}")


if __name__ == "__main__":
    main()
